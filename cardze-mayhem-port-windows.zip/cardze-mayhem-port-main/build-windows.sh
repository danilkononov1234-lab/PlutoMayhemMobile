#!/usr/bin/env bash
# Build mayhem-desktop.exe on Windows with MSYS2 (UCRT64 shell).
#
#   1. Install MSYS2 from https://www.msys2.org and open "MSYS2 UCRT64".
#   2. cd into this folder and run:   ./build-windows.sh
#
# The script installs the toolchain and libraries, fetches the upstream firmware
# at the pinned commit (needs internet and git), builds, and copies the .exe next
# to run.bat. Use  ./build-windows.sh --gui  to hide the console window.
set -euo pipefail

if [ "${MSYSTEM:-}" != "UCRT64" ]; then
    echo "Open the 'MSYS2 UCRT64' shell (current: ${MSYSTEM:-none}) and run this again." >&2
    exit 1
fi

GUI=OFF
[ "${1:-}" = "--gui" ] && GUI=ON

HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE"

P=mingw-w64-ucrt-x86_64
echo "==> Installing build dependencies"
pacman -S --needed --noconfirm \
    git make \
    $P-gcc $P-cmake $P-ninja $P-pkgconf $P-python \
    $P-SDL2 $P-SDL2_image \
    $P-rtl-sdr $P-libiio

# libad9361 is optional (PlutoSDR RF helpers); not every MSYS2 repo carries it.
pacman -S --needed --noconfirm $P-libad9361-iio 2>/dev/null || \
    echo "note: $P-libad9361-iio not available - PlutoSDR build may lack it"

FW=third_party/mayhem-firmware
PIN=77798cb09f227de5c58dea48899ddb7448b44a07
if [ ! -f "$FW/firmware/application/ui_navigation.cpp" ]; then
    echo "==> Fetching upstream Mayhem firmware ($PIN)"
    # Long upstream paths: let git on Windows handle them.
    git config --global core.longpaths true
    git clone https://github.com/portapack-mayhem/mayhem-firmware.git "$FW"
    git -C "$FW" checkout "$PIN"
    # The upstream repo uses submodules (chibios-portapack with FatFs).
    git -C "$FW" submodule update --init --recursive
fi

echo "==> Configuring"
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release \
    -DMAYHEM_WINDOWS_GUI="$GUI"

echo "==> Building"
cmake --build build -j"$(nproc)"

cp -f build/mayhem-desktop.exe ./mayhem-desktop.exe
echo
echo "Done: $HERE/mayhem-desktop.exe"
echo "Run it with run.bat (double-click), or ./package-windows.sh to make a portable folder."
