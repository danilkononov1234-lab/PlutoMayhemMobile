@echo off
rem Launcher for the PortaPack Mayhem desktop port (Windows).
rem The folder is self-contained: the exe sits next to its emulated SD card
rem (mayhem-sd\), so copying the whole folder keeps settings, captures and
rem playlists. Set MAYHEM_SD yourself beforehand to use another folder.
setlocal
set "HERE=%~dp0"
if not exist "%HERE%mayhem-desktop.exe" (
  echo mayhem-desktop.exe not found next to run.bat
  pause
  exit /b 1
)
if "%MAYHEM_SD%"=="" set "MAYHEM_SD=%HERE%mayhem-sd"
if not exist "%MAYHEM_SD%" mkdir "%MAYHEM_SD%"
"%HERE%mayhem-desktop.exe" %*
if errorlevel 1 pause
endlocal
