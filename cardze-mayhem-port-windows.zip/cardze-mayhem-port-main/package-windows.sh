#!/usr/bin/env bash
# Make a portable "Mayhem Desktop" folder (exe + the DLLs it needs + run.bat)
# that runs on a Windows PC without MSYS2 installed. Run in the MSYS2 UCRT64
# shell after ./build-windows.sh.
set -euo pipefail

HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE"
[ -f mayhem-desktop.exe ] || { echo "Build first: ./build-windows.sh" >&2; exit 1; }

OUT="dist/Mayhem Desktop"
rm -rf "$OUT"
mkdir -p "$OUT/mayhem-sd"
cp mayhem-desktop.exe run.bat "$OUT/"

# Copy every non-system DLL the exe links against (SDL2, libusb, librtlsdr,
# libiio, libwinpthread, ...), resolved through ldd. System DLLs (Windows\...)
# are skipped.
echo "==> Collecting DLLs"
ldd mayhem-desktop.exe | awk '/=>/ {print $3}' | grep -i '/ucrt64/' | sort -u | while read -r dll; do
    echo "  $(basename "$dll")"
    cp -f "$dll" "$OUT/"
done

cp -f README.windows.md LICENSE* "$OUT/" 2>/dev/null || true
echo
echo "Portable folder: $HERE/$OUT"
