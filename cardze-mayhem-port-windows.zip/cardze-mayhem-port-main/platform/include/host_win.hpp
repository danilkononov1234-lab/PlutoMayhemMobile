/*
 * Windows-only helpers that need <windows.h>.
 *
 * They live in their own translation unit (platform/src/host_win.cpp, built
 * with HOST_NO_FORCED) because the firmware's FatFs headers define WCHAR /
 * TCHAR as 16-bit integer types, which collide with <windows.h>. This header
 * is deliberately free of any Windows or firmware include so every other host
 * source can use it.
 *
 * PortaPack desktop port. GPLv3-or-later derived work.
 */
#ifndef __HOST_WIN_HPP__
#define __HOST_WIN_HPP__

#include <cstddef>
#include <cstdint>
#include <string>

namespace host_win {

/* Reserve + commit `size` zeroed, read/write bytes at the exact virtual address
 * `base` (the Windows counterpart of mmap(MAP_FIXED | MAP_ANONYMOUS)). Works at
 * 4 KiB page granularity even though Windows reserves in 64 KiB blocks. On
 * failure returns false and fills `error`. */
bool map_fixed(std::uintptr_t base, std::size_t size, std::string& error);

/* Backup-RAM persistence. Windows cannot map a file at an address that is not a
 * multiple of 64 KiB, so the region is an ordinary committed block that is
 * loaded from `file` here and written back by a flusher thread (about once a
 * second when it changed, and once more at exit). Calling it again re-points the
 * region at another file and reloads it. */
void backup_ram_bind(void* region, std::size_t size, const std::string& file);
void backup_ram_start_flusher();

/* Replace `to` with `from` (POSIX rename() semantics). */
bool replace_file(const char* from, const char* to);

/* Host power state for the status-bar battery icon. */
struct PowerInfo {
    bool battery_present{false};
    bool ac_known{false};
    bool ac_online{false};
    bool charging{false};
    int percent{-1};  /* -1 = unknown */
};
bool query_power(PowerInfo& out);

}  // namespace host_win

#endif /* __HOST_WIN_HPP__ */
