/*
 * Small portability layer between the host sources and the OS.
 *
 * On Linux every function is a thin forwarder to the POSIX call the port used
 * before, so behaviour there is unchanged. On Windows (MinGW-w64) it supplies
 * the pieces that do not exist or differ: HOME / XDG paths, *_r time functions,
 * one-argument mkdir, 64-bit seek/stat/truncate, rename that replaces.
 *
 * Intentionally does NOT include <windows.h> or <filesystem> (see host_win.hpp).
 *
 * PortaPack desktop port. GPLv3-or-later derived work.
 */
#ifndef __HOST_COMPAT_HPP__
#define __HOST_COMPAT_HPP__

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <string>

#include <sys/stat.h>
#include <sys/types.h>

#ifdef _WIN32
#include <direct.h>
#include <io.h>
#include "host_win.hpp"
#else
#include <unistd.h>
#endif

namespace hostc {

#ifdef _WIN32
inline constexpr const char* kPathSeps = "/\\";
#else
inline constexpr const char* kPathSeps = "/";
#endif

/* The user's home directory, or "" when it cannot be determined. */
inline std::string home_dir() {
#ifdef _WIN32
    if (const char* p = std::getenv("USERPROFILE")) {
        if (*p) return p;
    }
    const char* drive = std::getenv("HOMEDRIVE");
    const char* path = std::getenv("HOMEPATH");
    if (drive && path && *drive && *path) return std::string(drive) + path;
#endif
    if (const char* h = std::getenv("HOME")) {
        if (*h) return h;
    }
    return std::string();
}

/* Per-user configuration root: %APPDATA% on Windows, $XDG_CONFIG_HOME or
 * ~/.config elsewhere. */
inline std::string config_home() {
#ifdef _WIN32
    if (const char* a = std::getenv("APPDATA")) {
        if (*a) return a;
    }
#else
    if (const char* x = std::getenv("XDG_CONFIG_HOME")) {
        if (*x) return x;
    }
#endif
    const std::string home = home_dir();
    return home.empty() ? std::string(".config") : home + "/.config";
}

inline int set_env(const char* name, const char* value) {
#ifdef _WIN32
    return ::_putenv_s(name, value);
#else
    return ::setenv(name, value, 1);
#endif
}

inline void gmtime_r(const std::time_t* t, std::tm* out) {
#ifdef _WIN32
    /* gmtime() uses a per-thread buffer on the Windows CRT, so it is safe. */
    if (const std::tm* r = ::gmtime(t)) *out = *r;
#else
    ::gmtime_r(t, out);
#endif
}

inline void localtime_r(const std::time_t* t, std::tm* out) {
#ifdef _WIN32
    if (const std::tm* r = ::localtime(t)) *out = *r;
#else
    ::localtime_r(t, out);
#endif
}

inline std::time_t timegm(std::tm* t) {
#ifdef _WIN32
    return ::_mkgmtime(t);
#else
    return ::timegm(t);
#endif
}

inline int mkdir(const char* path) {
#ifdef _WIN32
    return ::_mkdir(path);
#else
    return ::mkdir(path, 0775);
#endif
}

inline int remove_dir(const char* path) {
#ifdef _WIN32
    return ::_rmdir(path);
#else
    return ::rmdir(path);
#endif
}

inline int remove_file(const char* path) {
#ifdef _WIN32
    return ::_unlink(path);
#else
    return ::unlink(path);
#endif
}

#ifdef _WIN32
using stat_t = struct _stat64;
inline int stat_file(const char* path, stat_t* st) { return ::_stat64(path, st); }
inline int fstat_fd(int fd, stat_t* st) { return ::_fstat64(fd, st); }
inline bool is_dir(const stat_t& st) { return (st.st_mode & _S_IFMT) == _S_IFDIR; }
inline int fseek64(std::FILE* f, std::int64_t off, int whence) { return ::_fseeki64(f, off, whence); }
inline int ftruncate64(int fd, std::int64_t size) { return ::_chsize_s(fd, size) == 0 ? 0 : -1; }
inline int rename_replace(const char* from, const char* to) {
    return host_win::replace_file(from, to) ? 0 : -1;
}
#else
using stat_t = struct stat;
inline int stat_file(const char* path, stat_t* st) { return ::stat(path, st); }
inline int fstat_fd(int fd, stat_t* st) { return ::fstat(fd, st); }
inline bool is_dir(const stat_t& st) { return S_ISDIR(st.st_mode); }
inline int fseek64(std::FILE* f, std::int64_t off, int whence) {
    return ::fseeko(f, static_cast<off_t>(off), whence);
}
inline int ftruncate64(int fd, std::int64_t size) { return ::ftruncate(fd, static_cast<off_t>(size)); }
inline int rename_replace(const char* from, const char* to) { return ::rename(from, to); }
#endif

}  // namespace hostc

#endif /* __HOST_COMPAT_HPP__ */
