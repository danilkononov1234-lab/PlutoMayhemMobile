/*
 * Windows implementations of the host helpers declared in host_win.hpp.
 *
 * Built with HOST_NO_FORCED (see CMakeLists.txt): it must not see the firmware's
 * force-included headers, whose FatFs integer types clash with <windows.h>.
 *
 * PortaPack desktop port. GPLv3-or-later derived work.
 */
#include "host_win.hpp"

#ifdef _WIN32

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>

#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <mutex>
#include <system_error>
#include <thread>
#include <vector>

namespace host_win {

namespace {

std::string last_error_text(const char* what) {
    const DWORD code = GetLastError();
    char buf[512];
    const DWORD n = FormatMessageA(
        FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, nullptr, code, 0,
        buf, static_cast<DWORD>(sizeof(buf)), nullptr);
    std::string out = std::string(what) + " failed (error " + std::to_string(code) + ")";
    if (n > 0) {
        std::string msg(buf, n);
        while (!msg.empty() && (msg.back() == '\r' || msg.back() == '\n' || msg.back() == ' '))
            msg.pop_back();
        out += ": " + msg;
    }
    return out;
}

/* ------------------------------------------------------------------------ */
/* Backup RAM persistence.                                                   */
/* ------------------------------------------------------------------------ */

bool read_whole(const std::string& path, void* dst, std::size_t size) {
    std::FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    const std::size_t n = std::fread(dst, 1, size, f);
    std::fclose(f);
    if (n < size) std::memset(static_cast<unsigned char*>(dst) + n, 0, size - n);
    return true;
}

bool write_whole(const std::string& path, const void* src, std::size_t size) {
    std::error_code ec;
    const std::filesystem::path p(path);
    if (p.has_parent_path()) std::filesystem::create_directories(p.parent_path(), ec);

    const std::string tmp = path + ".tmp";
    std::FILE* f = std::fopen(tmp.c_str(), "wb");
    if (!f) return false;
    const bool ok = std::fwrite(src, 1, size, f) == size;
    std::fclose(f);
    if (!ok) {
        std::remove(tmp.c_str());
        return false;
    }
    return replace_file(tmp.c_str(), path.c_str());
}

class BackupRam {
   public:
    void bind(void* region, std::size_t size, const std::string& file) {
        std::lock_guard<std::mutex> lk(m_);
        region_ = region;
        size_ = size;
        path_ = file;
        /* Load what a previous run stored; a missing file means a fresh, zeroed
         * (uncalibrated) pmem, which the firmware detects and fills with defaults. */
        if (!read_whole(path_, region_, size_)) std::memset(region_, 0, size_);
        shadow_.assign(static_cast<unsigned char*>(region_),
                       static_cast<unsigned char*>(region_) + size_);
    }

    void start() {
        std::lock_guard<std::mutex> lk(m_);
        if (started_) return;
        started_ = true;
        worker_ = std::thread([this] { run(); });
    }

    ~BackupRam() {
        {
            std::lock_guard<std::mutex> lk(m_);
            stop_ = true;
        }
        cv_.notify_all();
        if (worker_.joinable()) worker_.join();
        flush();
    }

   private:
    void run() {
        std::unique_lock<std::mutex> lk(m_);
        while (!stop_) {
            cv_.wait_for(lk, std::chrono::seconds(1));
            if (stop_) break;
            flush_locked();
        }
    }

    void flush() {
        std::lock_guard<std::mutex> lk(m_);
        flush_locked();
    }

    void flush_locked() {
        if (!region_ || path_.empty()) return;
        std::vector<unsigned char> now(static_cast<unsigned char*>(region_),
                                       static_cast<unsigned char*>(region_) + size_);
        if (now == shadow_) return;
        if (write_whole(path_, now.data(), now.size())) shadow_.swap(now);
    }

    std::mutex m_;
    std::condition_variable cv_;
    std::thread worker_;
    bool started_{false};
    bool stop_{false};
    void* region_{nullptr};
    std::size_t size_{0};
    std::string path_;
    std::vector<unsigned char> shadow_;
};

BackupRam& backup() {
    static BackupRam instance;
    return instance;
}

}  // namespace

bool map_fixed(std::uintptr_t base, std::size_t size, std::string& error) {
    SYSTEM_INFO si{};
    GetSystemInfo(&si);
    const std::uintptr_t gran = si.dwAllocationGranularity;  /* 64 KiB */

    const std::uintptr_t first = base & ~(gran - 1);
    const std::uintptr_t last = (base + size + gran - 1) & ~(gran - 1);

    /* Reserve every 64 KiB block the range touches that is still free. Blocks
     * that are already reserved (by an earlier call for a neighbouring region in
     * the same block) are reused; committing below tells us if they are foreign. */
    for (std::uintptr_t g = first; g < last; g += gran) {
        MEMORY_BASIC_INFORMATION mbi{};
        if (VirtualQuery(reinterpret_cast<void*>(g), &mbi, sizeof(mbi)) == 0) {
            error = last_error_text("VirtualQuery");
            return false;
        }
        if (mbi.State == MEM_FREE) {
            if (!VirtualAlloc(reinterpret_cast<void*>(g), gran, MEM_RESERVE, PAGE_READWRITE)) {
                error = last_error_text("VirtualAlloc(MEM_RESERVE)") +
                        " - the address range is already in use by this process";
                return false;
            }
        }
    }

    void* p = VirtualAlloc(reinterpret_cast<void*>(base), size, MEM_COMMIT, PAGE_READWRITE);
    if (p != reinterpret_cast<void*>(base)) {
        error = last_error_text("VirtualAlloc(MEM_COMMIT)");
        return false;
    }
    return true;
}

void backup_ram_bind(void* region, std::size_t size, const std::string& file) {
    backup().bind(region, size, file);
}

void backup_ram_start_flusher() {
    backup().start();
}

bool replace_file(const char* from, const char* to) {
    return MoveFileExA(from, to, MOVEFILE_REPLACE_EXISTING | MOVEFILE_COPY_ALLOWED) != 0;
}

bool query_power(PowerInfo& out) {
    SYSTEM_POWER_STATUS sps{};
    if (!GetSystemPowerStatus(&sps)) return false;

    /* BatteryFlag: 128 = no system battery, 255 = unknown. */
    out.battery_present = (sps.BatteryFlag != 255) && !(sps.BatteryFlag & 128);
    out.ac_known = (sps.ACLineStatus != 255);
    out.ac_online = (sps.ACLineStatus == 1);
    out.charging = out.battery_present && (sps.BatteryFlag != 255) && (sps.BatteryFlag & 8);
    out.percent = (sps.BatteryLifePercent <= 100) ? static_cast<int>(sps.BatteryLifePercent) : -1;
    return true;
}

}  // namespace host_win

#endif /* _WIN32 */
